


arrToday = [];
var id = 0;



function addUser() {
    var yetti = document.getElementById('7-10').value;
    var on = document.getElementById('10-12').value;
    var onikki = document.getElementById('12-15').value;
    var onbesh = document.getElementById('15-18').value;
    var onsakkiz = document.getElementById('18-22').value;
    var yegirmaikki = document.getElementById('22-24').value;


    id++;
    var obj = {
        id: id,
        yettiobj: yetti,
        onobj: on,
        onikkiobj: onikki,
        onbeshobj: onbesh,
        onsakkizobj: onsakkiz,
        yegirmaikkiobj: yegirmaikki,
    };

    arrToday.push(obj);

    chizish();

    document.getElementById('7-10').value = '';
    document.getElementById('10-12').value = '';
    document.getElementById('12-15').value = '';
    document.getElementById('15-18').value = '';
    document.getElementById('18-22').value = '';
    document.getElementById('22-24').value = '';

}



function chizish() {

    var tr = [];
    arrToday.forEach(function (item, index, array) {
        tr += '<tr>' +
            '<td>' + item.id + '</td>' +
            '<td>' + item.yettiobj +'</td>' +
            '<td>' + item.onobj + '</td>' +
            '<td>' + item.onikkiobj + '</td>' +
            '<td>' + item.onbeshobj + '</td>' +
            '<td>' + item.onsakkizobj + '</td>' +
            '<td>' + item.yegirmaikkiobj + '</td>' +
            '<td>' +
            '<button class="bg-danger" title="'+item.id +'" onclick="removeUser(this)"><i class="fa fa-trash-alt"></i> <b>Delete</b></button>' +
            '<button class="ml-3 bg-success" title="'+item.id +'" onclick="editUser(this)"><i class="fa fa-pencil-alt"></i> <b>Update</b></button>' +
            '</td>' +
            '</tr>'
    });
    document.getElementById('tbody').innerHTML = tr;
}

function removeUser(button) {
    var oldId = button.getAttribute('title');


    for (var i = 0; i < arrToday.length; i++){
        if (oldId == arrToday[i].id){
            arrToday.splice(i,1);
            console.log('asssalom');
            break;
        }

    }
    chizish();
}

function editUser(button) {

    var oldId = button.getAttribute("title");

    for (let i = 0; i < arrToday.length; i++){


        if (oldId == arrToday[i].id){

            document.getElementById('yetti').value = arrToday[i].yettiobj;
            document.getElementById('on').value = arrToday[i].onobj;
            document.getElementById('onikki').value = arrToday[i].onikkiobj;
            document.getElementById('onbesh').value = arrToday[i].onbeshobj;
            document.getElementById('onsakkiz').value = arrToday[i].onsakkizobj;
            document.getElementById('yegirmaikki').value = arrToday[i].yegirmaikki;

            document.getElementById('updateUser').style = "<button style='display: block'></button>"
            document.getElementById('updateUser').setAttribute('title',arrToday[i].id);
            break;

        }

    }

}

function updateUser(button) {

    var oldId  = button.getAttribute('title');

    var yetti = document.getElementById('7-10').value;
    var on = document.getElementById('10-12').value;
    var onikki = document.getElementById('12-15').value;
    var onbesh = document.getElementById('15-18').value;
    var onsakkiz = document.getElementById('18-22').value;
    var yegirmaikki = document.getElementById('22-24').value;


        var newobj ={
            id: oldId,
            yettiobj: yetti,
            onobj: on,
            onikkiobj: onikki,
            onbeshobj: onbesh,
            onsakkizobj: onsakkiz,
            yegirmaikkiobj: yegirmaikki,
        };

        for (let i = 0; i < arrToday.length; i++){
            if (oldId == arrToday[i].id){
                arrToday.splice(i,1,newobj);
                break;
            }
        }



        chizish();


        document.getElementById('7-10').value = '';
        document.getElementById('10-12').value = '';
        document.getElementById('12-15').value = '';
        document.getElementById('15-18').value = '';
        document.getElementById('18-22').value = '';
        document.getElementById('22-24').value = '';



}




function searchNamechUser() {

    if (document.getElementById('radioName').checked === true){

        var search = document.getElementById('searchInput').value;

        for (let i = 0; i < arrToday.length; i++){
            if (search == arrToday[i].yettiobj){
                chizish();
                console.log('dddd');
            }else {
                   arrToday[i].yettiobj = '';
                   arrToday[i].onobj = '';
                   arrToday[i].onikkiobj = '';
                   arrToday[i].onbeshobj = '';
                   arrToday[i].onsakkizobj = '';
                   arrToday[i].yegirmaikkiobj = '';

                document.getElementsByTagName("button");

            }
        }
    }

}



