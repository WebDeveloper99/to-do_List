

var userArray = [];
var id = 0;

function addUser() {
    var userName = document.getElementById('Name').value;
    var userFam = document.getElementById('familya').value;
    var userShar = document.getElementById('sharfi').value;
    var userJob = document.getElementById('kasbi').value;
    var userNum = document.getElementById('telraqami').value;

    if (userName && userFam && userShar && userNum && userJob !== '') {

        id++;
        var obj = {
            id: id,
            nameobj: userName,
            famobj: userFam,
            sharobj: userShar,
            jobobj: userJob,
            numobj: userNum,
        }

        userArray.push(obj);
        chizish();

        document.getElementById('Name').value = '';
        document.getElementById('familya').value = '';
        document.getElementById('sharfi').value = '';
        document.getElementById('kasbi').value = '';
        document.getElementById('telraqami').value = '';


    } else {
        alert('Qatorlarni to\'liq to\'ldiring');
    }


}

function chizish() {
    var tr = [];
    userArray.forEach(function (item, index, array) {
        tr += '<tr>' +
            '<td>' + item.id + '</td>' +
            '<td>' + item.nameobj + ' ' + item.famobj + ' ' + item.sharobj + '</td>' +
            '<td>' + item.jobobj + '</td>' +
            '<td>' + item.numobj + '</td>' +
            '<td>' +
            '<button class="bg-danger" title="'+item.id+'" onclick="removeUser(this)"><i class="fa fa-trash-alt"></i> <b>Delete</b></button>' +
            '<button class="ml-3 bg-success" title="'+item.id+'" onclick="editUser(this)"><i class="fa fa-pencil-alt"></i> <b>Update</b></button>' +
            '</td>' +
            '</tr>'
    });
    document.getElementById('tbody').innerHTML = tr;
}

function removeUser(button) {
    var oldId = button.getAttribute('title');

    for (var i = 0; i < userArray.length; i++){
        if (oldId == userArray[i].id){

            userArray.splice(i,1);
            console.log('sssss');

            break;
        }

    }
    chizish();
}

function editUser(button) {
    var oldId = button.getAttribute("title");

    for (let i = 0; i < userArray.length; i++){

        if (oldId == userArray[i].id){
            console.log(oldId);
            document.getElementById('Name').value = userArray[i].nameobj;
            document.getElementById('familya').value = userArray[i].famobj;
            document.getElementById('sharfi').value = userArray[i].sharobj;
            document.getElementById('kasbi').value = userArray[i].jobobj;
            document.getElementById('telraqami').value = userArray[i].numobj;

            document.getElementById('updateUser').style = "<button style='display: block'></button>"
            document.getElementById('updateUser').setAttribute('title',userArray[i].id);
            break;

        }

    }

}

function updateUser(button) {

    var oldId  = button.getAttribute('title');

    var name = document.getElementById('Name').value;
    var fam =  document.getElementById('familya').value;
    var shar =  document.getElementById('sharfi').value;
    var kasb = document.getElementById('kasbi').value;
    var tel = document.getElementById('telraqami').value;

    if (name && fam && shar && kasb && tel !== ''){

        var newobj ={
            id: oldId,
            nameobj: name,
            famobj: fam,
            sharobj: shar,
            jobobj: kasb,
            numobj: tel,
        };

        for (let i = 0; i < userArray.length; i++){
            if (oldId == userArray[i].id){
                userArray.splice(i,1,newobj);
                break;
            }
        }



        chizish();

        document.getElementById('Name').value = '';
        document.getElementById('familya').value = '';
        document.getElementById('sharfi').value = '';
        document.getElementById('kasbi').value = '';
        document.getElementById('telraqami').value = '';

    }else {
        alert('O\'zgarishlarni to\'liq to\'ldiring');
    }


}





function searchNamechUser() {

   if (document.getElementById('radioName').checked === true){

       var search = document.getElementById('searchInput').value;

       for (let i = 0; i < userArray.length; i++){
           if (search == userArray[i].nameobj){
               chizish();
               console.log('dddd');
           }else {
               userArray[i].nameobj = '';
               userArray[i].famobj = '';
               userArray[i].sharobj = '';
               userArray[i].jobobj = '' ;
               userArray[i].numobj = '';
               document.getElementsByTagName("button");

           }
       }
   }

}

function searJobchUser() {

    if (document.getElementById('radioKasb').checked === true){

        var search = document.getElementById('searchInput').value;

        for (let i = 0; i < userArray.length; i++){
            if (search == userArray[i].jobobj){
                chizish();
                console.log('dddd');
            }else {
                userArray[i].nameobj = '';
                userArray[i].famobj = '';
                userArray[i].sharobj = '';
                userArray[i].jobobj = '' ;
                userArray[i].numobj = '';
            }
        }
    }

}

function searchTelUser() {

    if (document.getElementById('radioTelNumber').checked === true){

        var search = document.getElementById('searchInput').value;

        for (let i = 0; i < userArray.length; i++){
            if (search == userArray[i].numobj){
                chizish();
                console.log('dddd');
            }else {
                userArray[i].nameobj = '';
                userArray[i].famobj = '';
                userArray[i].sharobj = '';
                userArray[i].jobobj = '' ;
                userArray[i].numobj = '';
                document.getElementsByTagName("button");

            }
        }
    }

}
